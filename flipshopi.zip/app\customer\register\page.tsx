"use client";

import { useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";

export default function CustomerRegister() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleRegister(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage("");
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            full_name: name.trim(),
            account_type: "customer",
          },
          emailRedirectTo: `${window.location.origin}/customer/login`,
        },
      });

      if (error) throw error;

      setMessage(
        data.session
          ? "आपका अकाउंट बन गया है! अब Login करें।"
          : "Registration अनुरोध सफल! अपने ईमेल में verification link देखें।"
      );
    } catch (err) {
      setMessage(
        err instanceof Error
          ? err.message
          : "Registration नहीं हो पाया। दोबारा कोशिश करें।"
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      <section className="bg-gradient-to-br from-emerald-800 to-green-600 text-white p-8 md:p-14 md:w-5/12 flex flex-col justify-center">
        <Link href="/" className="text-3xl font-extrabold mb-12">
          🛒 FlipShopi
        </Link>

        <p className="text-emerald-200 font-semibold mb-3">
          SMART GROCERY SHOPPING
        </p>

        <h1 className="text-4xl md:text-5xl font-bold leading-tight">
          आपकी हर जरूरत,
          <br />
          अब आपके दरवाजे पर।
        </h1>

        <p className="mt-6 text-emerald-50 leading-7">
          ताजे किराने के सामान की खरीदारी करें। आसान ऑर्डर,
          सुविधाजनक खरीदारी और शानदार अनुभव।
        </p>

        <div className="mt-10 space-y-3 text-sm text-emerald-50">
          <p>✓ आसान और सुरक्षित अकाउंट</p>
          <p>✓ सुविधाजनक ऑनलाइन खरीदारी</p>
          <p>✓ आपके लिए बेहतर अनुभव</p>
        </div>
      </section>

      <section className="flex-1 flex items-center justify-center p-5 md:p-10">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-100 p-7 sm:p-10">
          <div className="text-emerald-700 font-extrabold text-xl mb-7">
            FlipShopi <span className="text-slate-400 font-normal">/ Customer</span>
          </div>

          <h2 className="text-3xl font-bold text-slate-900">
            अपना अकाउंट बनाएँ
          </h2>

          <p className="text-slate-500 mt-2 mb-8">
            नीचे अपनी जानकारी भरकर रजिस्ट्रेशन करें।
          </p>

          <form onSubmit={handleRegister} className="space-y-5">
            <div>
              <label htmlFor="name" className="block text-sm font-semibold mb-2">
                पूरा नाम
              </label>
              <input
                id="name"
                type="text"
                autoComplete="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="अपना पूरा नाम लिखें"
                required
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-semibold mb-2">
                ईमेल पता
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-semibold mb-2">
                पासवर्ड
              </label>
              <input
                id="password"
                type="password"
                autoComplete="new-password"
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="कम से कम 6 अक्षर"
                required
                className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white font-bold py-3.5 transition-colors"
            >
              {loading ? "कृपया प्रतीक्षा करें..." : "Customer Registration →"}
            </button>
          </form>

          {message && (
            <p role="status" className="mt-5 rounded-xl bg-emerald-50 text-emerald-800 p-4 text-sm break-words">
              {message}
            </p>
          )}

          <div className="border-t border-slate-100 mt-7 pt-6 text-center text-sm text-slate-600 space-y-4">
            <p>
              पहले से अकाउंट है?{" "}
              <Link href="/customer/login" className="text-emerald-700 font-bold hover:underline">
                Login करें
              </Link>
            </p>

            <p>
              दुकान चलाते हैं?{" "}
              <Link href="/seller/register" className="text-emerald-700 font-bold hover:underline">
                Seller Registration
              </Link>
            </p>

            <Link href="/" className="inline-block text-slate-500 hover:text-emerald-700">
              ← होम पेज पर जाएँ
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}