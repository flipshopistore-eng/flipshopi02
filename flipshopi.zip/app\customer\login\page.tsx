"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function CustomerLoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleLogin(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const { data, error } =
        await supabase.auth.signInWithPassword({
          email,
          password,
        });

      if (error) {
        setMessage("लॉगिन नहीं हुआ। ईमेल और पासवर्ड जाँचें।");
        return;
      }

      const { data: profile, error: profileError } =
        await supabase
          .from("profiles")
          .select("role")
          .eq("id", data.user.id)
          .single();

      if (profileError || profile?.role !== "customer") {
        await supabase.auth.signOut();
        setMessage(
          "यह Customer अकाउंट नहीं है। कृपया सही लॉगिन पेज इस्तेमाल करें।"
        );
        return;
      }

      router.push("/customer/dashboard");
      router.refresh();
    } catch {
      setMessage("कुछ समस्या हुई। कृपया दोबारा कोशिश करें।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-green-50 via-white to-emerald-100 px-4 py-10">
      <div className="w-full max-w-md rounded-3xl border border-green-100 bg-white p-7 shadow-xl sm:p-10">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-green-600 text-3xl text-white shadow-lg">
            🛒
          </div>

          <h1 className="text-3xl font-extrabold tracking-tight text-gray-900">
            Flip<span className="text-green-600">Shopi</span>
          </h1>

          <p className="mt-2 text-sm text-gray-500">
            अपने अकाउंट में लॉगिन करें
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label
              htmlFor="email"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              ईमेल एड्रेस
            </label>

            <input
              id="email"
              type="email"
              placeholder="आपका ईमेल लिखें"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none transition focus:border-green-600 focus:ring-4 focus:ring-green-100"
            />
          </div>

          <div>
            <label
              htmlFor="password"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              पासवर्ड
            </label>

            <input
              id="password"
              type="password"
              placeholder="अपना पासवर्ड लिखें"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none transition focus:border-green-600 focus:ring-4 focus:ring-green-100"
            />
          </div>

          {message && (
            <div
              role="alert"
              className="rounded-xl bg-red-50 p-3 text-sm text-red-700"
            >
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-green-600 px-4 py-3.5 font-bold text-white shadow-md transition hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? "लॉगिन हो रहा है..." : "Login करें"}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-gray-200" />
          <span className="text-xs text-gray-400">नया अकाउंट?</span>
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        <Link
          href="/customer/register"
          className="block w-full rounded-xl border-2 border-green-600 px-4 py-3 text-center font-bold text-green-700 transition hover:bg-green-50"
        >
          नया Customer अकाउंट बनाएँ
        </Link>

        <p className="mt-7 text-center text-xs leading-5 text-gray-400">
          FlipShopi पर खरीदारी करने के लिए आपका स्वागत है।
        </p>
      </div>
    </main>
  );
}