
"use client";

import { useMemo, useState } from "react";

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
  emoji: string;
};

type Order = {
  id: string;
  customer: string;
  items: number;
  amount: number;
  status: string;
  time: string;
};

const initialProducts: Product[] = [
  { id: 1, name: "Fresh Tomatoes", category: "Vegetables", price: 30, stock: 45, emoji: "🍅" },
  { id: 2, name: "Fresh Milk 1L", category: "Dairy", price: 64, stock: 28, emoji: "🥛" },
  { id: 3, name: "Banana 6 pcs", category: "Fruits", price: 40, stock: 8, emoji: "🍌" },
  { id: 4, name: "Basmati Rice 5kg", category: "Staples", price: 420, stock: 14, emoji: "🍚" },
  { id: 5, name: "Fresh Bread", category: "Bakery", price: 45, stock: 4, emoji: "🍞" },
  { id: 6, name: "Potato 1kg", category: "Vegetables", price: 35, stock: 32, emoji: "🥔" },
];

const initialOrders: Order[] = [
  { id: "ORD-1042", customer: "Rahul Kumar", items: 4, amount: 385, status: "Delivered", time: "10:42 AM" },
  { id: "ORD-1043", customer: "Priya Singh", items: 2, amount: 164, status: "Preparing", time: "10:48 AM" },
  { id: "ORD-1044", customer: "Amit Sharma", items: 6, amount: 520, status: "Placed", time: "10:52 AM" },
  { id: "ORD-1045", customer: "Neha Kumari", items: 3, amount: 245, status: "Out for delivery", time: "11:02 AM" },
  { id: "ORD-1046", customer: "Rohit Verma", items: 5, amount: 690, status: "Placed", time: "11:10 AM" },
];

const navGroups = [
  {
    title: "OVERVIEW",
    items: [
      { label: "Dashboard", icon: "▦" },
      { label: "Orders", icon: "▤" },
    ],
  },
  {
    title: "CATALOGUE",
    items: [
      { label: "Products", icon: "▣" },
      { label: "Inventory", icon: "▥" },
      { label: "Categories", icon: "▧" },
    ],
  },
  {
    title: "BUSINESS",
    items: [
      { label: "Customers", icon: "♙" },
      { label: "Reports", icon: "▥" },
      { label: "Settings", icon: "⚙" },
    ],
  },
];

const money = (amount: number) =>
  "₹" + amount.toLocaleString("en-IN");

export default function AdminPage() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [active, setActive] = useState("Dashboard");
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState(initialProducts);
  const [orders, setOrders] = useState(initialOrders);
  const [showProductForm, setShowProductForm] = useState(false);
  const [productName, setProductName] = useState("");
  const [productCategory, setProductCategory] = useState("Vegetables");
  const [productPrice, setProductPrice] = useState("50");
  const [productStock, setProductStock] = useState("10");
  const [notice, setNotice] = useState("");

  const filteredProducts = useMemo(
    () =>
      products.filter((p) =>
        `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase())
      ),
    [products, search]
  );

  const filteredOrders = useMemo(
    () =>
      orders.filter((o) =>
        `${o.id} ${o.customer} ${o.status}`
          .toLowerCase()
          .includes(search.toLowerCase())
      ),
    [orders, search]
  );

  const revenue = orders
    .filter((o) => o.status === "Delivered")
    .reduce((sum, o) => sum + o.amount, 0);

  const lowStock = products.filter((p) => p.stock < 10);

  function login(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (password === "Grocery@2026!") {
      setLoggedIn(true);
      setPassword("");
      setLoginError("");
    } else {
      setLoginError("गलत पासवर्ड। दोबारा कोशिश करें।");
    }
  }

  function addProduct(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!productName.trim()) return;

    const nextProduct: Product = {
      id: Date.now(),
      name: productName.trim(),
      category: productCategory,
      price: Math.max(0, Number(productPrice) || 0),
      stock: Math.max(0, Number(productStock) || 0),
      emoji:
        productCategory === "Fruits" ? "🍎" :
        productCategory === "Dairy" ? "🥛" :
        productCategory === "Bakery" ? "🍞" :
        productCategory === "Staples" ? "🍚" : "🥬",
    };

    setProducts((prev) => [nextProduct, ...prev]);
    setProductName("");
    setProductPrice("50");
    setProductStock("10");
    setShowProductForm(false);
    setNotice("Product सफलतापूर्वक जोड़ा गया।");
    setTimeout(() => setNotice(""), 2500);
  }

  function changeOrderStatus(id: string, status: string) {
    setOrders((prev) =>
      prev.map((order) => (order.id === id ? { ...order, status } : order))
    );
  }

  function deleteProduct(id: number) {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setNotice("Product हटाया गया।");
    setTimeout(() => setNotice(""), 2500);
  }

  if (!loggedIn) {
    return (
      <main className="login-screen">
        <form className="login-card" onSubmit={login}>
          <div className="login-logo">🛒</div>
          <div className="login-brand">FRESH<span>CART</span></div>
          <h1>Welcome back!</h1>
          <p className="muted">Sign in to your store dashboard</p>
          <label htmlFor="admin-password">Admin password</label>
          <input
            id="admin-password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {loginError && <p className="error">{loginError}</p>}
          <button className="primary-btn login-btn" type="submit">
            Sign in to dashboard →
          </button>
          <p className="login-foot">Store management portal</p>
        </form>
        <style jsx>{styles}</style>
      </main>
    );
  }

  return (
    <div className="admin-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">F</div>
          <div>
            <strong>freshcart</strong>
            <small>STORE ADMIN</small>
          </div>
        </div>

        <div className="store-status">
          <span className="live-dot" />
          <span>Store is online</span>
          <span className="status-chevron">⌄</span>
        </div>

        <nav className="side-nav">
          {navGroups.map((group) => (
            <div key={group.title} className="nav-group">
              <p className="nav-heading">{group.title}</p>
              {group.items.map((item) => (
                <button
                  key={item.label}
                  className={`nav-item ${active === item.label ? "selected" : ""}`}
                  onClick={() => {
                    setActive(item.label);
                    setSearch("");
                  }}
                >
                  <span className="nav-icon">{item.icon}</span>
                  {item.label}
                  {item.label === "Orders" && (
                    <span className="nav-count">{orders.length}</span>
                  )}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon">✦</div>
            <strong>Need some help?</strong>
            <p>Manage your store with confidence.</p>
            <button onClick={() => setActive("Settings")}>Help center ↗</button>
          </div>
          <button className="profile" onClick={() => setActive("Settings")}>
            <div className="avatar">A</div>
            <div className="profile-text">
              <strong>Store Admin</strong>
              <small>Administrator</small>
            </div>
            <span>•••</span>
          </button>
          <button className="logout" onClick={() => setLoggedIn(false)}>
            ↪ &nbsp; Sign out
          </button>
        </div>
      </aside>

      <section className="main-area">
        <header className="topbar">
          <div className="breadcrumb">Store / <strong>{active}</strong></div>
          <div className="top-actions">
            <div className="search-box">
              <span>⌕</span>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={`Search ${active.toLowerCase()}...`}
              />
              <kbd>⌘ K</kbd>
            </div>
            <button className="icon-button" title="Notifications" onClick={() => setNotice("आपके पास कोई नई सूचना नहीं है।")}>♧</button>
            <div className="top-avatar">A</div>
          </div>
        </header>

        <main className="content">
          {notice && <div className="notice">{notice}</div>}

          {active === "Dashboard" && (
            <>
              <div className="page-heading">
                <div>
                  <p className="eyebrow">TUESDAY, STORE OVERVIEW</p>
                  <h1>Good morning, Admin <span>✦</span></h1>
                  <p className="muted">Here&apos;s what&apos;s happening with your store today.</p>
                </div>
                <button className="primary-btn" onClick={() => { setActive("Products"); setShowProductForm(true); }}>
                  ＋ Add new product
                </button>
              </div>

              <div className="welcome-banner">
                <div>
                  <span className="banner-label">YOUR STORE AT A GLANCE</span>
                  <h2>Fresh groceries.<br />Happy customers.</h2>
                  <p>Keep your inventory fresh and your customers happy.</p>
                  <button onClick={() => setActive("Orders")}>View all orders →</button>
                </div>
                <div className="banner-art" aria-hidden="true">
                  <span>🥑</span><span>🥦</span><span>🍊</span><span>🥕</span>
                </div>
                <div className="banner-circle" />
              </div>

              <div className="section-title">
                <div><h2>Store performance</h2><p>Summary of your store activity</p></div>
                <span className="period-pill">● Live overview</span>
              </div>

              <div className="stats-grid">
                <StatCard title="Total revenue" value={money(revenue)} icon="₹" color="green" detail="From delivered demo orders" />
                <StatCard title="Total orders" value={String(orders.length)} icon="▤" color="purple" detail="Orders in this demo" />
                <StatCard title="Total products" value={String(products.length)} icon="▣" color="orange" detail="Products in catalogue" />
                <StatCard title="Low stock items" value={String(lowStock.length)} icon="!" color="red" detail="Products below 10 units" />
              </div>

              <div className="dashboard-grid">
                <section className="panel recent-panel">
                  <div className="panel-heading">
                    <div><h3>Recent orders</h3><p>Your latest customer orders</p></div>
                    <button className="text-button" onClick={() => setActive("Orders")}>View all →</button>
                  </div>
                  <div className="table-wrap">
                    <table>
                      <thead><tr><th>ORDER</th><th>CUSTOMER</th><th>AMOUNT</th><th>STATUS</th></tr></thead>
                      <tbody>
                        {orders.slice(0, 4).map((o) => (
                          <tr key={o.id}>
                            <td className="order-id">{o.id}</td>
                            <td>{o.customer}</td>
                            <td className="amount">{money(o.amount)}</td>
                            <td><Status status={o.status} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>

                <section className="panel inventory-panel">
                  <div className="panel-heading">
                    <div><h3>Stock alerts</h3><p>Items that need attention</p></div>
                    <button className="text-button" onClick={() => setActive("Inventory")}>View all →</button>
                  </div>
                  {lowStock.length === 0 ? (
                    <div className="empty">All products have healthy stock.</div>
                  ) : lowStock.map((p) => (
                    <div className="stock-row" key={p.id}>
                      <div className="product-emoji">{p.emoji}</div>
                      <div className="stock-info"><strong>{p.name}</strong><small>{p.category}</small></div>
                      <span className="stock-number">{p.stock} left</span>
                    </div>
                  ))}
                </section>
              </div>
              <div className="demo-note">ⓘ Demo dashboard · The figures and orders shown here are sample data.</div>
            </>
          )}

          {active === "Orders" && (
            <>
              <div className="page-heading">
                <div><p className="eyebrow">ORDER MANAGEMENT</p><h1>Orders</h1><p className="muted">Track orders and update delivery status.</p></div>
              </div>
              <div className="stats-grid compact-stats">
                <StatCard title="All orders" value={String(orders.length)} icon="▤" color="green" detail="All demo orders" />
                <StatCard title="Placed" value={String(orders.filter(o => o.status === "Placed").length)} icon="◷" color="orange" detail="Awaiting preparation" />
                <StatCard title="Preparing" value={String(orders.filter(o => o.status === "Preparing").length)} icon="♨" color="purple" detail="Being packed" />
                <StatCard title="Delivered" value={String(orders.filter(o => o.status === "Delivered").length)} icon="✓" color="green" detail="Completed orders" />
              </div>
              <section className="panel table-panel">
                <div className="panel-heading"><div><h3>All orders</h3><p>Change the status using the dropdown.</p></div></div>
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>ORDER ID</th><th>CUSTOMER</th><th>ITEMS</th><th>AMOUNT</th><th>TIME</th><th>STATUS</th></tr></thead>
                    <tbody>{filteredOrders.map(o => (
                      <tr key={o.id}>
                        <td className="order-id">{o.id}</td><td>{o.customer}</td><td>{o.items} items</td><td className="amount">{money(o.amount)}</td><td>{o.time}</td>
                        <td><select className="status-select" value={o.status} onChange={e => changeOrderStatus(o.id, e.target.value)}>
                          {["Placed", "Preparing", "Out for delivery", "Delivered", "Cancelled"].map(s => <option key={s}>{s}</option>)}
                        </select></td>
                      </tr>
                    ))}</tbody>
                  </table>
                  {filteredOrders.length === 0 && <div className="empty">No matching orders found.</div>}
                </div>
              </section>
            </>
          )}

          {active === "Products" && (
            <>
              <div className="page-heading">
                <div><p className="eyebrow">PRODUCT CATALOGUE</p><h1>Products</h1><p className="muted">Manage your grocery catalogue, pricing and stock.</p></div>
                <button className="primary-btn" onClick={() => setShowProductForm(!showProductForm)}>{showProductForm ? "✕ Close form" : "＋ Add product"}</button>
              </div>

              {showProductForm && (
                <form className="panel product-form" onSubmit={addProduct}>
                  <h3>Add a new product</h3>
                  <div className="form-grid">
                    <label>Product name<input required value={productName} onChange={e => setProductName(e.target.value)} placeholder="e.g. Fresh Apples" /></label>
                    <label>Category<select value={productCategory} onChange={e => setProductCategory(e.target.value)}>{["Vegetables", "Fruits", "Dairy", "Bakery", "Staples", "Snacks", "Beverages"].map(c => <option key={c}>{c}</option>)}</select></label>
                    <label>Price (₹)<input type="number" min="0" required value={productPrice} onChange={e => setProductPrice(e.target.value)} /></label>
                    <label>Stock quantity<input type="number" min="0" required value={productStock} onChange={e => setProductStock(e.target.value)} /></label>
                  </div>
                  <button className="primary-btn" type="submit">Save product</button>
                </form>
              )}

              <section className="panel table-panel">
                <div className="panel-heading"><div><h3>All products <span className="count-badge">{products.length}</span></h3><p>Search, review and remove catalogue items.</p></div></div>
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>PRODUCT</th><th>CATEGORY</th><th>PRICE</th><th>STOCK</th><th>AVAILABILITY</th><th>ACTION</th></tr></thead>
                    <tbody>{filteredProducts.map(p => (
                      <tr key={p.id}>
                        <td><div className="table-product"><div className="product-emoji">{p.emoji}</div><strong>{p.name}</strong></div></td>
                        <td>{p.category}</td><td className="amount">{money(p.price)}</td><td>{p.stock}</td>
                        <td><Status status={p.stock < 10 ? "Low stock" : "In stock"} /></td>
                        <td><button className="delete-btn" onClick={() => deleteProduct(p.id)}>Remove</button></td>
                      </tr>
                    ))}</tbody>
                  </table>
                  {filteredProducts.length === 0 && <div className="empty">No matching products found.</div>}
                </div>
              </section>
            </>
          )}

          {active === "Inventory" && (
            <>
              <div className="page-heading"><div><p className="eyebrow">STOCK CONTROL</p><h1>Inventory</h1><p className="muted">Monitor stock levels and replenish low-stock items.</p></div><button className="primary-btn" onClick={() => setActive("Products")}>Manage products →</button></div>
              <div className="stats-grid">
                <StatCard title="Total SKUs" value={String(products.length)} icon="▣" color="green" detail="Unique products" />
                <StatCard title="Low stock" value={String(lowStock.length)} icon="!" color="red" detail="Fewer than 10 units" />
                <StatCard title="Out of stock" value={String(products.filter(p => p.stock === 0).length)} icon="×" color="orange" detail="Unavailable items" />
                <StatCard title="Units in stock" value={String(products.reduce((n,p) => n + p.stock, 0))} icon="▥" color="purple" detail="Across all products" />
              </div>
              <section className="panel table-panel"><div className="panel-heading"><div><h3>Stock overview</h3><p>Stock below 10 units is marked low.</p></div></div>
                <div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>CATEGORY</th><th>STOCK LEVEL</th><th>STATUS</th></tr></thead><tbody>
                  {products.map(p => <tr key={p.id}><td><div className="table-product"><div className="product-emoji">{p.emoji}</div><strong>{p.name}</strong></div></td><td>{p.category}</td><td><div className="stock-bar"><span style={{width: `${Math.min(100, p.stock * 2)}%`}} /></div><small>{p.stock} units</small></td><td><Status status={p.stock < 10 ? "Low stock" : p.stock === 0 ? "Out of stock" : "In stock"} /></td></tr>)}
                </tbody></table></div>
              </section>
            </>
          )}

          {active === "Categories" && (
            <>
              <div className="page-heading"><div><p className="eyebrow">PRODUCT ORGANIZATION</p><h1>Categories</h1><p className="muted">Browse categories in your current catalogue.</p></div></div>
              <div className="category-grid">{Array.from(new Set(products.map(p => p.category))).map((category, i) => {
                const icons: Record<string,string> = {Vegetables:"🥦",Fruits:"🍎",Dairy:"🥛",Bakery:"🍞",Staples:"🌾",Snacks:"🍿",Beverages:"🧃"};
                return <button className="category-card" key={category} onClick={() => {setSearch(category);setActive("Products");}}><span>{icons[category] || "🛒"}</span><strong>{category}</strong><small>{products.filter(p => p.category === category).length} products</small></button>;
              })}</div>
            </>
          )}

          {active === "Customers" && (
            <>
              <div className="page-heading"><div><p className="eyebrow">CUSTOMER MANAGEMENT</p><h1>Customers</h1><p className="muted">Customer names from sample orders.</p></div></div>
              <section className="panel table-panel"><div className="table-wrap"><table><thead><tr><th>CUSTOMER</th><th>ORDERS</th><th>TOTAL SPENT</th><th>LATEST ORDER</th></tr></thead><tbody>
                {Array.from(new Set(orders.map(o => o.customer))).filter(c => c.toLowerCase().includes(search.toLowerCase())).map(customer => {
                  const customerOrders = orders.filter(o => o.customer === customer);
                  return <tr key={customer}><td><div className="table-product"><div className="avatar">{customer.charAt(0)}</div><strong>{customer}</strong></div></td><td>{customerOrders.length}</td><td className="amount">{money(customerOrders.reduce((s,o) => s + o.amount,0))}</td><td>{customerOrders[0]?.id}</td></tr>;
                })}
              </tbody></table></div></section>
            </>
          )}

          {active === "Reports" && (
            <>
              <div className="page-heading"><div><p className="eyebrow">BUSINESS INSIGHTS</p><h1>Reports</h1><p className="muted">Summary calculated from the sample orders.</p></div></div>
              <div className="stats-grid"><StatCard title="Delivered revenue" value={money(revenue)} icon="₹" color="green" detail="Delivered orders only" /><StatCard title="Average order value" value={money(orders.length ? Math.round(orders.reduce((s,o) => s + o.amount,0) / orders.length) : 0)} icon="↗" color="purple" detail="All sample orders" /><StatCard title="Delivered orders" value={String(orders.filter(o => o.status === "Delivered").length)} icon="✓" color="orange" detail="Completed orders" /><StatCard title="Cancelled orders" value={String(orders.filter(o => o.status === "Cancelled").length)} icon="×" color="red" detail="Cancelled orders" /></div>
              <section className="panel report-panel"><h3>Orders by status</h3>{["Placed","Preparing","Out for delivery","Delivered","Cancelled"].map(status => {
                const count = orders.filter(o => o.status === status).length;
                const percent = orders.length ? (count / orders.length) * 100 : 0;
                return <div className="report-row" key={status}><div><span>{status}</span><strong>{count}</strong></div><div className="report-track"><span style={{width:`${percent}%`}} /></div></div>;
              })}</section>
            </>
          )}

          {active === "Settings" && (
            <>
              <div className="page-heading"><div><p className="eyebrow">STORE CONFIGURATION</p><h1>Settings</h1><p className="muted">Your demo store profile and session options.</p></div></div>
              <section className="panel settings-panel"><h3>Store profile</h3><div className="settings-row"><div><strong>Store name</strong><p>FreshCart Grocery Store</p></div><span className="settings-tag">Demo</span></div><div className="settings-row"><div><strong>Admin access</strong><p>Current browser session</p></div><button className="secondary-btn" onClick={() => setLoggedIn(false)}>Lock panel</button></div><div className="settings-row"><div><strong>Data storage</strong><p>Demo data is kept in React state and resets on refresh.</p></div><span className="settings-tag">Local only</span></div></section>
            </>
          )}
        </main>
      </section>

      <style jsx>{styles}</style>
    </div>
  );
}

function StatCard({ title, value, icon, color, detail }: {title:string;value:string;icon:string;color:string;detail:string}) {
  return <div className="stat-card"><div className={`stat-icon ${color}`}>{icon}</div><p className="stat-title">{title}</p><div className="stat-value">{value}</div><p className="stat-detail">{detail}</p></div>;
}

function Status({ status }: {status:string}) {
  const kind = status === "Delivered" || status === "In stock" ? "good" :
    status === "Preparing" || status === "Out for delivery" ? "progress" :
    status === "Low stock" || status === "Placed" ? "warning" : "neutral";
  return <span className={`status ${kind}`}><span />{status}</span>;
}

const styles = `
:global(*) { box-sizing: border-box; }
:global(body) { margin: 0; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: #17251d; }
:global(button), :global(input), :global(select) { font: inherit; }
:global(button) { transition: .15s ease; }
:global(button:focus-visible), :global(input:focus-visible), :global(select:focus-visible) { outline: 3px solid #bbf7d0; outline-offset: 2px; }
.admin-shell { min-height: 100vh; background: #f7f9f7; }
.sidebar { position: fixed; inset: 0 auto 0 0; width: 248px; background: #fff; border-right: 1px solid #e8eee9; display: flex; flex-direction: column; padding: 24px 15px 14px; z-index: 5; }
.brand { display: flex; align-items: center; gap: 11px; padding: 0 9px 26px; }
.brand-icon { width: 39px; height: 39px; display: grid; place-items: center; border-radius: 12px; color: #fff; font-weight: 900; font-size: 23px; background: #169447; }
.brand strong { display: block; font-size: 21px; letter-spacing: -.8px; }
.brand small { display: block; margin-top: 3px; color: #87938b; font-size: 9px; font-weight: 800; letter-spacing: 1.8px; }
.store-status { display: flex; align-items: center; gap: 9px; border: 1px solid #e7eee8; padding: 11px; border-radius: 10px; font-size: 12px; color: #526157; }
.live-dot { width: 8px; height: 8px; background: #16a34a; border-radius: 50%; box-shadow: 0 0 0 3px #dcfce7; }
.status-chevron { margin-left: auto; }
.side-nav { overflow-y: auto; padding-top: 18px; }
.nav-group { margin-bottom: 21px; }
.nav-heading { font-size: 10px; font-weight: 800; letter-spacing: 1.2px; color: #9aa49d; padding: 0 11px; margin: 0 0 8px; }
.nav-item { display: flex; align-items: center; gap: 12px; width: 100%; text-align: left; padding: 11px; margin: 3px 0; border: 0; border-radius: 9px; color: #657168; background: transparent; cursor: pointer; font-size: 13px; }
.nav-item:hover { background: #f5f8f5; }
.nav-item.selected { background: #e9f8ee; color: #16803e; font-weight: 700; }
.nav-icon { font-size: 18px; width: 19px; text-align: center; }
.nav-count { margin-left: auto; background: #dcfce7; color: #166534; padding: 2px 7px; border-radius: 6px; font-size: 10px; }
.sidebar-bottom { margin-top: auto; }
.help-card { background: #f3f9f4; border: 1px solid #e2f0e5; border-radius: 12px; padding: 14px; margin: 12px 0; }
.help-icon { color: #169447; font-size: 22px; margin-bottom: 8px; }
.help-card strong { font-size: 12px; }
.help-card p { font-size: 11px; line-height: 1.5; color: #78857c; }
.help-card button { border: 0; background: transparent; color: #16803e; font-weight: 700; font-size: 11px; padding: 0; cursor: pointer; }
.profile { display: flex; align-items: center; gap: 9px; border: 0; background: transparent; width: 100%; padding: 12px 3px; text-align: left; cursor: pointer; border-top: 1px solid #edf1ed; }
.avatar, .top-avatar { display: grid; place-items: center; width: 34px; height: 34px; border-radius: 50%; background: #d9f1df; color: #16723b; font-weight: 800; flex-shrink: 0; }
.profile-text { flex: 1; }
.profile-text strong, .profile-text small { display: block; }
.profile-text strong { font-size: 12px; }
.profile-text small { font-size: 10px; color: #8b958e; margin-top: 3px; }
.profile > span { color: #7b867e; }
.logout { width: 100%; text-align: left; background: transparent; border: 0; color: #758078; padding: 9px 6px; cursor: pointer; font-size: 12px; }
.main-area { margin-left: 248px; min-width: 0; }
.topbar { height: 70px; background: rgba(255,255,255,.94); border-bottom: 1px solid #e9eee9; display: flex; align-items: center; justify-content: space-between; padding: 0 34px; gap: 20px; }
.breadcrumb { font-size: 12px; color: #9aa49d; }
.breadcrumb strong { color: #334238; font-weight: 700; }
.top-actions { display: flex; align-items: center; gap: 14px; }
.search-box { width: 245px; height: 37px; display: flex; align-items: center; gap: 8px; padding: 0 10px; border: 1px solid #e4eae5; background: #fafcfb; border-radius: 9px; color: #89958d; }
.search-box input { width: 100%; min-width: 0; border: 0; outline: 0; background: transparent; font-size: 11px; }
.search-box kbd { font-size: 9px; white-space: nowrap; background: #f0f3f0; padding: 4px; border-radius: 4px; }
.icon-button { width: 36px; height: 36px; border: 1px solid #e8ede9; border-radius: 9px; background: white; cursor: pointer; color: #58645b; }
.top-avatar { width: 34px; height: 34px; }
.content { max-width: 1600px; margin: 0 auto; padding: 30px 34px 48px; }
.page-heading { display: flex; align-items: center; justify-content: space-between; gap: 18px; margin-bottom: 24px; }
.eyebrow { font-size: 9px; font-weight: 800; color: #169447; letter-spacing: 1.4px; margin: 0 0 8px; }
.page-heading h1 { font-size: clamp(23px, 2vw, 29px); letter-spacing: -1px; margin: 0; }
.page-heading h1 span { color: #e8aa30; font-size: 19px; }
.muted { color: #8a968d; font-size: 12px; margin: 8px 0 0; line-height: 1.5; }
.primary-btn { background: #168d43; border: 1px solid #168d43; color: #fff; border-radius: 9px; padding: 11px 16px; font-size: 12px; font-weight: 700; cursor: pointer; white-space: nowrap; }
.primary-btn:hover { background: #116d34; }
.welcome-banner { position: relative; overflow: hidden; min-height: 180px; border-radius: 16px; padding: 24px 28px; background: linear-gradient(105deg,#176c38,#21964d); color: white; display: flex; justify-content: space-between; align-items: center; }
.banner-label { font-size: 9px; font-weight: 800; letter-spacing: 1.6px; color: #c8f3d4; }
.welcome-banner h2 { font-size: 26px; letter-spacing: -.8px; line-height: 1.17; margin: 10px 0; }
.welcome-banner p { font-size: 11px; color: #d5f0dc; }
.welcome-banner button { margin-top: 6px; border: 0; background: white; color: #176c38; font-size: 11px; font-weight: 800; padding: 10px 13px; border-radius: 8px; cursor: pointer; position: relative; z-index: 2; }
.banner-art { position: relative; z-index: 1; display: flex; align-items: center; gap: 5px; font-size: clamp(36px, 4vw, 60px); transform: rotate(-6deg); padding-right: 35px; }
.banner-art span:nth-child(even) { transform: translateY(15px) rotate(10deg); }
.banner-circle { position: absolute; width: 230px; height: 230px; right: 60px; top: -30px; border: 1px solid #ffffff20; border-radius: 50%; box-shadow: 0 0 0 35px #ffffff08,0 0 0 70px #ffffff08; }
.section-title { display: flex; align-items: center; justify-content: space-between; margin: 27px 0 14px; }
.section-title h2 { font-size: 16px; margin: 0; }
.section-title p { font-size: 11px; color: #89958d; margin: 5px 0 0; }
.period-pill { font-size: 10px; border: 1px solid #e3ece4; background: #fff; border-radius: 20px; padding: 7px 10px; color: #4b7e59; }
.stats-grid { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 15px; margin-bottom: 24px; }
.stat-card { min-width: 0; padding: 18px; background: #fff; border: 1px solid #e9eee9; border-radius: 13px; }
.stat-icon { width: 35px; height: 35px; display: grid; place-items: center; border-radius: 10px; font-weight: 800; font-size: 17px; margin-bottom: 15px; }
.stat-icon.green { color: #16803e; background: #e6f8eb; }
.stat-icon.purple { color: #7b55cb; background: #f0eafe; }
.stat-icon.orange { color: #c47c1b; background: #fff2dc; }
.stat-icon.red { color: #d44747; background: #ffebeb; }
.stat-title { font-size: 11px; color: #7c887f; margin: 0 0 8px; }
.stat-value { font-size: clamp(22px,2vw,28px); letter-spacing: -.8px; font-weight: 800; }
.stat-detail { font-size: 10px; color: #97a198; margin: 8px 0 0; }
.dashboard-grid { display: grid; grid-template-columns: minmax(0,1.7fr) minmax(250px,1fr); gap: 18px; }
.panel { background: #fff; border: 1px solid #e8eee9; border-radius: 13px; overflow: hidden; min-width: 0; }
.panel-heading { padding: 20px 20px 15px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
.panel-heading h3, .product-form h3, .report-panel h3, .settings-panel h3 { font-size: 14px; margin: 0; }
.panel-heading p { color: #8d9990; font-size: 10px; margin: 5px 0 0; }
.text-button { border: 0; background: transparent; color: #168d43; font-size: 11px; font-weight: 700; cursor: pointer; }
.table-wrap { overflow-x: auto; width: 100%; }
table { border-collapse: collapse; width: 100%; font-size: 11px; text-align: left; white-space: nowrap; }
th { background: #fafcfb; color: #8b978e; font-size: 9px; letter-spacing: .6px; font-weight: 800; }
th, td { padding: 13px 17px; border-bottom: 1px solid #f0f3f0; }
tbody tr:last-child td { border-bottom: 0; }
td { color: #58645b; }
.order-id { font-weight: 800; color: #334b3a; }
.amount { font-weight: 800; color: #26382b; }
.status { display: inline-flex; align-items: center; gap: 5px; border-radius: 20px; padding: 5px 8px; font-size: 9px; font-weight: 700; }
.status > span { width: 5px; height: 5px; border-radius: 50%; background: currentColor; }
.status.good { color: #16803e; background: #e8f8ed; }
.status.progress { color: #6350bd; background: #f0ecff; }
.status.warning { color: #b97715; background: #fff5df; }
.status.neutral { color: #69746c; background: #edf0ed; }
.inventory-panel { padding-bottom: 6px; }
.stock-row { display: flex; align-items: center; gap: 10px; padding: 12px 18px; border-top: 1px solid #f0f3f0; }
.product-emoji { width: 36px; height: 36px; flex-shrink: 0; display: grid; place-items: center; border-radius: 9px; background: #f4f8f3; font-size: 20px; }
.stock-info { flex: 1; min-width: 0; }
.stock-info strong, .stock-info small { display: block; }
.stock-info strong { font-size: 11px; }
.stock-info small { color: #929d94; font-size: 10px; margin-top: 4px; }
.stock-number { color: #b97715; background: #fff4dd; padding: 5px 7px; border-radius: 6px; font-size: 9px; font-weight: 800; }
.demo-note { margin-top: 20px; color: #89958d; font-size: 10px; }
.compact-stats { margin-top: 6px; }
.table-panel { margin-top: 18px; }
.status-select { border: 1px solid #e2e9e3; background: white; border-radius: 7px; padding: 7px; color: #46544a; font-size: 10px; max-width: 145px; }
.product-form { padding: 22px; margin-bottom: 18px; }
.product-form h3 { margin-bottom: 17px; }
.form-grid { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 14px; margin-bottom: 17px; }
.form-grid label { display: flex; flex-direction: column; gap: 7px; font-size: 11px; color: #69756c; }
.form-grid input, .form-grid select { width: 100%; padding: 11px; border: 1px solid #e0e7e1; border-radius: 8px; background: #fff; color: #26382b; }
.count-badge { background: #e8f8ed; color: #16803e; padding: 4px 7px; border-radius: 6px; font-size: 10px; margin-left: 5px; }
.table-product { display: flex; align-items: center; gap: 9px; }
.table-product strong { color: #39483d; }
.delete-btn { border: 1px solid #f3d6d6; color: #c24141; background: #fff7f7; padding: 7px 9px; border-radius: 7px; cursor: pointer; font-size: 10px; }
.delete-btn:hover { background: #fee2e2; }
.stock-bar { display: inline-block; width: 75px; height: 6px; background: #edf2ee; border-radius: 9px; margin-right: 8px; vertical-align: middle; overflow: hidden; }
.stock-bar span { display: block; height: 100%; background: #20a451; border-radius: 9px; }
.empty { padding: 25px; text-align: center; color: #8b978e; font-size: 12px; }
.category-grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 15px; }
.category-card { display: flex; flex-direction: column; align-items: flex-start; gap: 9px; border: 1px solid #e8eee9; border-radius: 13px; background: #fff; padding: 22px; cursor: pointer; text-align: left; }
.category-card:hover { border-color: #91d7a5; transform: translateY(-2px); }
.category-card > span { font-size: 30px; }
.category-card strong { font-size: 13px; }
.category-card small { font-size: 10px; color: #89958d; }
.report-panel { padding: 23px; margin-top: 20px; }
.report-panel h3 { margin-bottom: 22px; }
.report-row { margin-bottom: 20px; }
.report-row > div:first-child { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 11px; }
.report-row strong { color: #16803e; }
.report-track { height: 9px; background: #edf2ee; border-radius: 20px; overflow: hidden; }
.report-track span { display: block; height: 100%; background: #1b984b; border-radius: 20px; }
.settings-panel { padding: 23px; }
.settings-panel h3 { margin-bottom: 8px; }
.settings-row { display: flex; align-items: center; justify-content: space-between; gap: 14px; padding: 18px 0; border-top: 1px solid #edf1ed; }
.settings-row strong { font-size: 12px; }
.settings-row p { font-size: 11px; color: #8b978e; margin: 5px 0 0; }
.settings-tag { background: #e8f8ed; color: #16803e; font-size: 10px; font-weight: 700; padding: 6px 9px; border-radius: 7px; }
.secondary-btn { border: 1px solid #dfe8e0; background: #fff; border-radius: 8px; padding: 9px 12px; font-size: 11px; cursor: pointer; }
.notice { background: #e8f8ed; border: 1px solid #bce8c8; color: #166534; padding: 12px 16px; margin-bottom: 18px; border-radius: 9px; font-size: 12px; }
.login-screen { min-height: 100vh; display: grid; place-items: center; padding: 20px; background: radial-gradient(ellipse at top left,#e0f7e6,transparent 55%),#f5f8f5; }
.login-card { width: 100%; max-width: 390px; padding: 34px; border: 1px solid #e5ede6; border-radius: 18px; background: #fff; box-shadow: 0 18px 55px #183e2410; }
.login-logo { width: 54px; height: 54px; display: grid; place-items: center; background: #e8f8ed; border-radius: 15px; font-size: 27px; margin-bottom: 15px; }
.login-brand { font-weight: 900; font-size: 13px; letter-spacing: 2px; color: #166534; }
.login-brand span { color: #1ca352; }
.login-card h1 { font-size: 25px; margin: 25px 0 0; letter-spacing: -.6px; }
.login-card .muted { margin-bottom: 25px; }
.login-card label { display: block; font-size: 11px; font-weight: 700; margin-bottom: 8px; }
.login-card input { width: 100%; padding: 13px; border: 1px solid #dfe8e0; border-radius: 9px; margin-bottom: 15px; outline-color: #86d59c; }
.login-btn { width: 100%; }
.login-foot { font-size: 10px; text-align: center; color: #9aa49d; margin: 22px 0 0; }
.error { color: #c24141; font-size: 11px; margin: -4px 0 12px; }
@media(max-width:1100px) { .sidebar { width: 215px; } .main-area { margin-left: 215px; } .content { padding: 25px 22px 40px; } .topbar { padding: 0 22px; } .stats-grid { grid-template-columns: repeat(2,minmax(0,1fr)); } .dashboard-grid { grid-template-columns: 1fr; } }
@media(max-width:700px) { .sidebar { position: relative; width: 100%; height: auto; padding: 15px; } .brand { padding-bottom: 14px; } .store-status, .sidebar-bottom, .nav-heading, .help-card { display: none; } .side-nav { display: flex; overflow-x: auto; gap: 7px; padding: 0; } .nav-group { display: flex; margin: 0; gap: 5px; } .nav-item { width: auto; flex-shrink: 0; padding: 9px 11px; margin: 0; } .nav-icon { display: none; } .main-area { margin-left: 0; } .topbar { height: auto; min-height: 60px; padding: 12px 15px; flex-wrap: wrap; } .top-actions { width: 100%; } .search-box { flex: 1; width: auto; } .content { padding: 22px 14px 35px; } .page-heading { align-items: flex-start; flex-direction: column; } .welcome-banner { padding: 22px; } .banner-art { position: absolute; right: -25px; bottom: 7px; opacity: .45; padding: 0; } .banner-art span { font-size: 38px; } .banner-circle { right: -90px; } .stats-grid { gap: 10px; } .stat-card { padding: 13px; } .stat-detail { line-height: 1.4; } .category-grid { grid-template-columns: repeat(2,minmax(0,1fr)); } .form-grid { grid-template-columns: 1fr; } .panel-heading { padding: 16px; } .settings-row { align-items: flex-start; } }
`;

