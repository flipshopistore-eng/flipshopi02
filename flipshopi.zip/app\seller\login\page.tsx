"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function SellerLoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setMessage("लॉगिन नहीं हुआ। ईमेल और पासवर्ड जाँचें।");
        return;
      }

      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", data.user.id)
        .single();

      if (profileError || profile?.role !== "seller") {
        await supabase.auth.signOut();
        setMessage(
          "यह Seller अकाउंट नहीं है। कृपया सही लॉगिन पेज इस्तेमाल करें।"
        );
        return;
      }

      router.push("/seller/dashboard");
      router.refresh();
    } catch {
      setMessage("कुछ समस्या हुई। कृपया दोबारा कोशिश करें।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-orange-50 via-white to-amber-100 px-4 py-10">
      <div className="w-full max-w-md rounded-3xl border border-orange-100 bg-white p-7 shadow-xl sm:p-10">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500 text-3xl text-white">
            🏪
          </div>

          <h1 className="text-3xl font-extrabold text-gray-900">
            Flip<span className="text-orange-500">Shopi</span>
          </h1>

          <p className="mt-2 text-sm text-gray-500">Seller Login</p>
          <p className="mt-1 text-sm text-gray-400">
            अपनी दुकान में लॉगिन करें
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label
              htmlFor="email"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              ईमेल एड्रेस
            </label>

            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="अपना ईमेल लिखें"
              autoComplete="email"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          <div>
            <label
              htmlFor="password"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              पासवर्ड
            </label>

            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="अपना पासवर्ड लिखें"
              autoComplete="current-password"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          {message && (
            <p
              role="alert"
              className="rounded-xl bg-red-50 p-3 text-sm text-red-700"
            >
              {message}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-orange-500 px-4 py-3.5 font-bold text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? "लॉगिन हो रहा है..." : "Seller Login करें"}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-gray-200" />
          <span className="text-xs text-gray-400">या</span>
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        <p className="text-center text-sm text-gray-600">
          नया Seller अकाउंट चाहिए?
        </p>

        <Link
          href="/seller/register"
          className="mt-3 block w-full rounded-xl border-2 border-orange-500 px-4 py-3 text-center font-bold text-orange-600 transition hover:bg-orange-50"
        >
          Seller Register करें
        </Link>

        <p className="mt-7 text-center text-xs text-gray-400">
          FlipShopi Seller Portal
        </p>
      </div>
    </main>
  );
}