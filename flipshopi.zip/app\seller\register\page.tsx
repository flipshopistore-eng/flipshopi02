"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function SellerRegisterPage() {
  const router = useRouter();

  const [name, setName] = useState("");
  const [shopName, setShopName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleRegister(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
            account_type: "seller",
          },
          emailRedirectTo: `${window.location.origin}/seller/login`,
        },
      });

      if (error) {
        setMessage(error.message);
        return;
      }

      if (!data.user) {
        setMessage("रजिस्ट्रेशन पूरा नहीं हुआ। कृपया दोबारा कोशिश करें।");
        return;
      }

      // यदि ईमेल verification बंद है और session मिला है,
      // तो नई दुकान pending approval के साथ बनाएँ।
      if (data.session) {
        const { error: storeError } = await supabase.from("stores").insert({
          owner_id: data.user.id,
          name: shopName,
          approval_status: "pending",
        });

        if (storeError) {
          setMessage(
            "अकाउंट बन गया है, लेकिन दुकान सेव नहीं हुई। कृपया सहायता लें।"
          );
          return;
        }

        router.push("/seller/login?registered=1");
        return;
      }

      setMessage(
        "रजिस्ट्रेशन सफल! अपने ईमेल में आए verification लिंक पर क्लिक करें। उसके बाद Seller Login करें।"
      );
    } catch {
      setMessage("कुछ समस्या हुई। कृपया दोबारा कोशिश करें।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-orange-50 via-white to-amber-100 px-4 py-10">
      <div className="w-full max-w-lg rounded-3xl border border-orange-100 bg-white p-7 shadow-xl sm:p-10">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500 text-3xl text-white shadow-lg">
            🏪
          </div>

          <h1 className="text-3xl font-extrabold text-gray-900">
            Flip<span className="text-orange-500">Shopi</span>
          </h1>

          <p className="mt-2 text-sm text-gray-500">
            Seller Registration
          </p>

          <p className="mt-1 text-sm text-gray-400">
            अपनी दुकान FlipShopi पर शुरू करें
          </p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label
              htmlFor="name"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              आपका पूरा नाम
            </label>

            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="अपना नाम लिखें"
              autoComplete="name"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          <div>
            <label
              htmlFor="shopName"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              दुकान का नाम
            </label>

            <input
              id="shopName"
              type="text"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              placeholder="जैसे: Shani Grocery Store"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          <div>
            <label
              htmlFor="email"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              ईमेल एड्रेस
            </label>

            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="अपना ईमेल लिखें"
              autoComplete="email"
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          <div>
            <label
              htmlFor="password"
              className="mb-2 block text-sm font-semibold text-gray-700"
            >
              पासवर्ड
            </label>

            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="कम से कम 6 अक्षर"
              autoComplete="new-password"
              minLength={6}
              required
              className="w-full rounded-xl border border-gray-300 px-4 py-3 text-gray-900 outline-none focus:border-orange-500 focus:ring-4 focus:ring-orange-100"
            />
          </div>

          {message && (
            <p
              role="alert"
              className="rounded-xl bg-orange-50 p-3 text-sm text-orange-800"
            >
              {message}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-orange-500 px-4 py-3.5 font-bold text-white shadow-md transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? "रजिस्ट्रेशन हो रहा है..." : "Seller अकाउंट बनाएँ"}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-gray-200" />
          <span className="text-xs text-gray-400">या</span>
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        <p className="text-center text-sm text-gray-600">
          पहले से Seller हैं?
        </p>

        <Link
          href="/seller/login"
          className="mt-3 block w-full rounded-xl border-2 border-orange-500 px-4 py-3 text-center font-bold text-orange-600 transition hover:bg-orange-50"
        >
          Seller Login करें
        </Link>

        <p className="mt-7 text-center text-xs leading-5 text-gray-400">
          रजिस्ट्रेशन के बाद आपकी दुकान की जाँच और approval किया जा सकता है।
        </p>
      </div>
    </main>
  );
}